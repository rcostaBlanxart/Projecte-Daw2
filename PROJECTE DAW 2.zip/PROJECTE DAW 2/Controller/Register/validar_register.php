<?php

include("../connexio_bd.php");

if ($conn ->connect_error) {
    die("Connection failed: " . $conn ->connect_error);
}

//Rebre dades del formulari
$username = $_POST['username'];
$nom = $_POST['nom'];
$cognom = $_POST['cognom'];
$dni = $_POST['dni'];
$email = $_POST['email'];
$password = $_POST['password'];
$confPassword = $_POST['confPassword'];


$username = mysqli_real_escape_string($conn, $username);
$nom = mysqli_real_escape_string($conn, $nom);
$cognom = mysqli_real_escape_string($conn, $cognom);
$dni = mysqli_real_escape_string($conn, $dni);
$email = mysqli_real_escape_string($conn, $email);
$password = mysqli_real_escape_string($conn, $password);
$confPassword = mysqli_real_escape_string($conn, $confPassword);

$password_hash = password_hash($password, PASSWORD_DEFAULT);


$emailExists = false;
$stmt = $conn->prepare("SELECT email FROM usuari WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$resultEmailExists = $stmt->get_result();


if ($resultEmailExists->num_rows > 0) {
    $emailExists = true;
}

$usernameExists = false;
$stmt2 = $conn->prepare("SELECT username FROM usuari WHERE username = ?");
$stmt2->bind_param("s", $username);
$stmt2->execute();
$resultUsernameExists = $stmt2->get_result();

if ($resultUsernameExists->num_rows > 0) {
    $usernameExists = true;
}


// If email already exists, show error message
if ($emailExists) {
    session_start();
    $_SESSION["error"] = "emailExists";
    header("location:../../Views/html/register.php");
}else if ($usernameExists){
    session_start();
    $_SESSION["error"] = "usernameExists";
    header("location:../../Views/html/register.php");
}
else{
    // If email does not exist, insert user into table
    $stmt = $conn->prepare("INSERT INTO usuari (username, nom, cognom, dni, email, password, id_tipo_usuari) VALUES (?, ?, ?, ?, ?, ?, 3)");
    $stmt->bind_param("ssssss",$username,$nom,$cognom,$dni,$email,$password_hash);
    $stmt->execute();

    header("location:../../Views/html/login.php");
}




//Prepara la consulta
// $sql = $conn->prepare("INSERT INTO usuari (nom, email, password, id_tipo_usuari) VALUES (?, ?, ?, 3)");

// $sql->bind_param("sss",$nom,$email,$password);

// $ejecutar=$sql->execute();

// $resultado=$sql->get_result();



// try{
//     $sql = $conn->prepare("INSERT INTO usuari (nom, email, password, id_tipo_usuari) VALUES (?, ?, ?, 3)");
//     $sql->bind_param("sss",$nom,$email,$password);
//     $sql->execute();

//     $html = file_get_contents("../../Views/register.php");
//     $html = str_replace(" <div class='alert alert-danger col-12 text-center'>ESTE CORREO YA ESTA REGISTRADO</div>", "<span></span>", $html);
//     file_put_contents("../../Views/register.php", $html);
    
//     header("location:../../Views/login.php");


    
// }catch (Exception $e) {
//     header("location:../../Views/register.php");
//     $html = file_get_contents("../../Views/register.php");
//     $html = str_replace("<span></span>", " <div class='alert alert-danger col-12 text-center'>ESTE CORREO YA ESTA REGISTRADO</div>", $html);
//     file_put_contents("../../Views/register.php", $html);
// }



// if($ejecutar==false){
//     header("location:../../Views/register.php");
// }else{
//     header("location:../../Views/login.php");
// }







mysqli_close($conn);