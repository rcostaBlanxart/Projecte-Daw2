<?php
$email = $_POST["email"];
$password = $_POST["password"];


include("connexio_bd.php");

if ($conn ->connect_error) {
    die("Connection failed: " . $conn ->connect_error);
}

//EVITAR MYSQL INYECTIONS

//Preparem la consulta sql
$sql=$conn->prepare("SELECT * FROM usuari WHERE email = ? and password = ?");


//Vinculem els paràmetres a la consulta
$sql->bind_param("ss",$email,$password);

//Executem la consulta
$sql->execute();

//Obtenim el resultat
$resultado=$sql->get_result();
// $resultado = $conn->query($sql);
$rows=mysqli_num_rows($resultado);

//IDENTIFICAR
$resultTipo = $conn->query("SELECT id_tipo_usuari FROM usuari WHERE email = '$email' ");
$rowTipo = $resultTipo->fetch_assoc();
$tipoUsuario = $rowTipo["id_tipo_usuari"];

if($rows){
    session_start();
    $_SESSION["email"]=$email;
    if($tipoUsuario==1){
        header("location:../../Views/admin.html");
        
    }else{
        header("location:../../Views/pruebInSes.html"); 
    }

    // Leemos el contenido del archivo en una cadena de texto
    $html = file_get_contents("../../Views/login1.html");

    // Eliminamos el contenido que queremos
    $html = str_replace(" <div class='alert alert-danger col-12 text-center'>USUARIO NO ENCONTRADO</div>", "<span></span>", $html);

    // Escribimos la cadena de texto modificada en el archivo
    file_put_contents("../../Views/login1.html", $html);
    
}else{
    // Leemos el contenido del archivo en una cadena de texto
    $html = file_get_contents("../../Views/login1.html");
    
    // Añadimos el contenido nuevo a la línea deseada
    $html = str_replace("<span></span>", " <div class='alert alert-danger col-12 text-center'>USUARIO NO ENCONTRADO</div>", $html);
    
    // Escribimos la cadena de texto modificada en el archivo
    file_put_contents("../../Views/login1.html", $html);
    
    // Redirigimos al usuario a la página login1.html
    header("location:../../Views/login1.html");
}
mysqli_close($conn);