<?php
$email = $_POST["email"];
$password = $_POST["password"];


include("connexio_bd.php");

if ($conn ->connect_error) {
    die("Connection failed: " . $conn ->connect_error);
}

//Preparem la consulta sql
$sql=$conn->prepare("SELECT * FROM usuari WHERE email = ? and password = ?");

//Vinculem els paràmetres a la consulta
$sql->bind_param("ss",$email,$password);

//Executem la consulta
$sql->execute();

//Obtenim el resultat
$resultado=$sql->get_result();
// $resultado = $conn->query($sql);
$rows=mysqli_num_rows($resultado);

if($rows){
    session_start();
    $_SESSION["email"]=$email;
    header("location:../../Views/pruebInSes.html");
}else{
        include("../../Views/login1.html");
        echo '<div class="alert alert-danger col-12 text-center">USUARIO NO ENCONTRADO</div>';
}
mysqli_free_result($resultado);
mysqli_close($conn);