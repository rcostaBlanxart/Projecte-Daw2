<?php
$email = $_POST["email"];
$password = $_POST["password"];


include("../connexio_bd.php");

if ($conn ->connect_error) {
    die("Connection failed: " . $conn ->connect_error);
}

//EVITAR MYSQL INYECTIONS

//Preparem la consulta sql
// $sql=$conn->prepare("SELECT * FROM usuari WHERE email = ? and password = ?");
$sql=$conn->prepare("SELECT password FROM usuari WHERE email = ?");


//Vinculem els paràmetres a la consulta
// $sql->bind_param("ss",$email,$password);
$sql->bind_param("s",$email);

//Executem la consulta
$sql->execute();

//Obtenim el resultat
$resultado=$sql->get_result();
$rows=mysqli_num_rows($resultado);
$user=$resultado->fetch_assoc();

//IDENTIFICAR
$resultTipo = $conn->query("SELECT id_tipo_usuari FROM usuari WHERE email = '$email' ");
$rowTipo = $resultTipo->fetch_assoc();
$tipoUsuario = $rowTipo["id_tipo_usuari"];



if($rows && password_verify($password, $user['password'])){
    session_start();
    $_SESSION["email"]=$email;
    $_SESSION["username"]=$user["username"];
    if($tipoUsuario==1){
        $_SESSION["usuari"] = 1;
    }else if($tipoUsuario==2){
        $_SESSION["usuari"] = 2;
    }else if($tipoUsuario==3){
        $_SESSION["usuari"] = 3;
    }
    $_SESSION["error"] = 0;
    header("location:../../Views/html/home_page.php");

}else{
    session_start();
    $_SESSION["error"] = 1;
    header("location:../../Views/html/login.php");
}



// if($rows){
//     session_start();
//     $_SESSION["email"]=$email;
//     if($tipoUsuario==1||$tipoUsuario==3){
//         header("location:../../Views/home_page.html");
        
//     }else{
//         header("location:../../Views/pruebInSes.html"); 
//     }

//     // Leemos el contenido del archivo en una cadena de texto
//     $html = file_get_contents("../../Views/login.php");

//     // Eliminamos el contenido que queremos
//     $html = str_replace(" <div class='alert alert-danger col-12 text-center' id='msg-error'>EL CORREU O LA CONTRASENYA SÓN INCORRECTES</div>", "<div id='msg-error'></div>", $html);

//     // Escribimos la cadena de texto modificada en el archivo
//     file_put_contents("../../Views/login.php", $html);
    
// }else{
//     // Leemos el contenido del archivo en una cadena de texto
//     $html = file_get_contents("../../Views/login.php");
    
//     // Añadimos el contenido nuevo a la línea deseada
//     $html = str_replace("<div id='msg-error'></div>", " <div class='alert alert-danger col-12 text-center' id='msg-error'>EL CORREU O LA CONTRASENYA SÓN INCORRECTES</div>", $html);
    
//     // Escribimos la cadena de texto modificada en el archivo
//     file_put_contents("../../Views/login.php", $html);
    
//     // Redirigimos al usuario a la página login.php
//     header("location:../../Views/login.php");
// }
mysqli_close($conn);