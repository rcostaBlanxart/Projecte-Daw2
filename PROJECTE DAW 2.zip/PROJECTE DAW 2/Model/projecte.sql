DROP DATABASE IF exists projecte;
CREATE DATABASE projecte;
USE projecte;

DELIMITER $$
CREATE TRIGGER actualizar
AFTER INSERT ON usuari
FOR EACH ROW
BEGIN
    SET @archivo = CONCAT('SELECT * FROM usuari INTO OUTFILE "projecte.sql"');
    PREPARE stmt FROM @archivo;
    EXECUTE stmt;
END$$
DELIMITER ;



CREATE TABLE tipo_usuari (
    id_tipo_usuari INT NOT NULL PRIMARY KEY,
    nom_tipo VARCHAR(20) NOT NULL,
    permisos VARCHAR(255) NOT NULL
);

CREATE TABLE usuari (
    id_usuari INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(30) NOT NULL UNIQUE,
    nom VARCHAR(30) NOT NULL,
    cognom VARCHAR (30) NOT NULL,
    dni VARCHAR (15) NOT NULL UNIQUE,
    email VARCHAR(60) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    id_tipo_usuari INT NOT NULL,
    FOREIGN KEY (id_tipo_usuari) REFERENCES tipo_usuari(id_tipo_usuari)
);

-- CREATE TABLE profesors (
--   id_profesor INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
--   nom VARCHAR(255) NOT NULL,
--   email VARCHAR(255) NOT NULL UNIQUE,
--   numero_telefono INT NOT NULL,
--   dni VARCHAR(9) NOT NULL
-- );

CREATE TABLE curs (
    id_curs INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nom_curs VARCHAR(60),
    descripcio VARCHAR(200),
    horari VARCHAR(60),
    data_inici DATE,
    data_fi DATE,
    id_profesor INT,
    preu FLOAT,
    placesDisponibles INT,
    FOREIGN KEY (id_profesor) REFERENCES profesors(id_profesor)
);

CREATE TABLE reserva (
    id_reserva INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    id_usuari INT NOT NULL,
    id_curs INT NOT NULL,
    FOREIGN KEY (id_usuari) REFERENCES usuari(id_usuari),
    FOREIGN KEY (id_curs) REFERENCES curs(id_curs)
);


INSERT INTO tipo_usuari VALUES
(1, "Admin", "Crear, eliminar y modificar crusos."),
(2, "Profesor", "Accede a información privilegiada sobre los cursos que hace."),
(3, "Usuari", "Solo puede ver los crusos y reservarlos.");

INSERT INTO usuari (username, nom, cognom, dni, email, password, id_tipo_usuari) VALUES 
("rcosta","Roger", "Costa", "20572037D", "rcosta@insdanielblanxart.cat", "$2y$10$.lucc7ufxNEcCnYjhvm9l.fkSWJTNQkr6RoIFx12NQgDoHFRZm29C", 1);

INSERT INTO profesors (nom, email, numero_telefono, dni) VALUES
-- id_profesor, nom, email, numero_telefono, dni
("Juan Garcia","jgarcia@gmail.com",666555444,"20802090F"),
("Alberto Diaz","adiaz@gmail.com",656755948,"10101091D"),
("Sandra Gómez","sgomez@gmail.com",624357894,"56864293N");


INSERT INTO curs (nom_curs, descripcio, horari, data_inici, data_fi, id_profesor, preu, placesDisponibles) VALUES
('Inglés para principiantes', 'Aprende conceptos básicos de la grámatcia inglesa.', 'Lunes y miercoles a las 6pm', "2023-09-12", "2024-02-17", 1, 299.99, 30);

