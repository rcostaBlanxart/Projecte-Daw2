<?php 

// include("../../Model/Conexion/connexio_bd.php");
// include("ModelCursos.php");

// <div id="plDispo"><?php

// $id_curs=1;

// $sql = "SELECT placesDisponibles FROM curs WHERE id_curs = '$id_curs'";
// $result = mysqli_query($conn, $sql);
// $row = mysqli_fetch_assoc($result);

// if($row['placesDisponibles']>0)
// echo $row['placesDisponibles']." Plaçes disponibles";
// else{
// echo "<p style='color:red;'> No quedan plaçes disponibles!</p>"
// <script> document.getElementById("reserva").disabled="true"; document.getElementById("reserva").style="opacity:30%;"; </script>
// <?php }

// </div>