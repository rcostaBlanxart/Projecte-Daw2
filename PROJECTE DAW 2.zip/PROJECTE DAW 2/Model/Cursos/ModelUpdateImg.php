<?php
// Connexió a la BD
include ("../../Model/Conexion/connexio_bd.php");

class ModelUpdateImg {

  private $conn;
    
  public function __construct($conn) {
      $this->conn = $conn;
  }

  public function updateImg($id_curs) 
  {
    if (isset($_POST['submit'])) {
        $file = $_FILES['file'];
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];
        $fileType = $file['type'];
      
        $fileExt = strtolower(end(explode('.', $fileName)));
        $allowed = array('jpg', 'jpeg', 'png', 'gif');
      
        if (in_array($fileExt, $allowed)) {
          if ($fileError === 0) {
            if ($fileSize < 1000000) {

              // Obtener la ruta de la imagen a eliminar
              $sqlImgOld = $this->conn->prepare("SELECT img FROM img_cursos WHERE id_curs = ?");
              $sqlImgOld->bind_param("s", $id_curs);
              $sqlImgOld->execute();
              $result = $sqlImgOld->get_result();

              if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $imgName = $row['img'];

                // Eliminar el archivo actual
                unlink("../../Views/img/$imgName");
              }

              $fileNameNew = uniqid('', true).".".$fileExt;
              $fileDestination = '../../Views/img/'.$fileNameNew;
              move_uploaded_file($fileTmpName, $fileDestination);
              echo "El archivo se ha subido correctamente.";

              // Update la ruta de l'imatge a la taula d'imatges de la BD
              $sql = $this->conn->prepare("UPDATE img_cursos SET img = ? WHERE id_curs= ?");
              $sql->bind_param("ss",$fileNameNew,$id_curs);
              return $sql->execute();

            } else {
              echo "El archivo es demasiado grande.";
              //Quiero que el echo de arriba salga de color rojo
            }
          } else {
            echo "Ha ocurrido un error al subir el archivo.";
          }
        } else {
          echo "No se permiten archivos de este tipo.";
        }
      }
  }
}
?>