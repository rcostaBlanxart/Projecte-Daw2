<?php
// MODELO //////////////////////////////////////////

function register($username, $nom, $cognom, $dni, $email, $password, $confPassword) {
    include ("../../Model/Conexion/connexio_bd.php");

    if ($conn ->connect_error) {
        die("Connection failed: " . $conn ->connect_error);
    }

    $username = mysqli_real_escape_string($conn, $username);
    $nom = mysqli_real_escape_string($conn, $nom);
    $cognom = mysqli_real_escape_string($conn, $cognom);
    $dni = mysqli_real_escape_string($conn, $dni);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);
    $confPassword = mysqli_real_escape_string($conn, $confPassword);
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $errorExists = false;
    
    $stmt = $conn->prepare("SELECT email FROM usuari WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultEmailExists = $stmt->get_result();

    if ($resultEmailExists->num_rows > 0) {
        $errorExists = true;
    }
    
    $stmt2 = $conn->prepare("SELECT username FROM usuari WHERE username = ?");
    $stmt2->bind_param("s", $username);
    $stmt2->execute();
    $resultUsernameExists = $stmt2->get_result();
    
    if ($resultUsernameExists->num_rows > 0) {
        $errorExists = true;
    }   

    if($errorExists){
        return false;
    }else{
        // If email does not exist, insert user into table
        $stmt = $conn->prepare("INSERT INTO usuari (username, nom, cognom, dni, email, password, id_tipo_usuari) VALUES (?, ?, ?, ?, ?, ?, 3)");
        $stmt->bind_param("ssssss",$username,$nom,$cognom,$dni,$email,$password_hash);
        $stmt->execute();
        return true;
    }
    mysqli_close($conn);
}




function register($username, $nom, $cognom, $dni, $email, $password, $confPassword) {
    include ("../../Model/Conexion/connexio_bd.php");

    if ($conn ->connect_error) {
        die("Connection failed: " . $conn ->connect_error);
    }

    $username = mysqli_real_escape_string($conn, $username);
    $nom = mysqli_real_escape_string($conn, $nom);
    $cognom = mysqli_real_escape_string($conn, $cognom);
    $dni = mysqli_real_escape_string($conn, $dni);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);
    $confPassword = mysqli_real_escape_string($conn, $confPassword);
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $errorExists = 0;
    
    $stmt = $conn->prepare("SELECT email FROM usuari WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultEmailExists = $stmt->get_result();

    if ($resultEmailExists->num_rows > 0) {
        $errorExists = 2;
    }
    
    $stmt2 = $conn->prepare("SELECT username FROM usuari WHERE username = ?");
    $stmt2->bind_param("s", $username);
    $stmt2->execute();
    $resultUsernameExists = $stmt2->get_result();
    
    if ($resultUsernameExists->num_rows > 0) {
        $errorExists = 1;
    }   

    if($errorExists != 0){
        return $errorExists;
    }else{
        // If email does not exist, insert user into table
        $stmt = $conn->prepare("INSERT INTO usuari (username, nom, cognom, dni, email, password, id_tipo_usuari) VALUES (?, ?, ?, ?, ?, ?, 3)");
        $stmt->bind_param("ssssss",$username,$nom,$cognom,$dni,$email,$password_hash);
        $stmt->execute();
        return true;
    }
    mysqli_close($conn);
}





// CONTROLADOR //////////////////////////////////////////

include ('../../Model/Register/ModelRegister.php'); 

//Rebre dades del formulari
$username = $_POST['username'];
$nom = $_POST['nom'];
$cognom = $_POST['cognom'];
$dni = $_POST['dni'];
$email = $_POST['email'];
$password = $_POST['password'];
$confPassword = $_POST['confPassword'];

$registerSuccess = register($username, $nom, $cognom, $dni, $email, $password, $confPassword);

if ($registerSuccess) {
    header("location:../../Views/html/login.php");
} else {
    session_start();
    $_SESSION["error"] = "emailExists";
    header("location:../../Views/html/register.php");
}

