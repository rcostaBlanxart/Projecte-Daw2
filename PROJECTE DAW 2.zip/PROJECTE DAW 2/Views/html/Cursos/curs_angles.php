<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrapstyle.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Informació del curs</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../../css/cursos.css">
  </head>
  <body>
    <!-- NAVBAR & DROPDOWN-->
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <h5 class="text-white h4">Collapsed content</h5>
        <span class="text-white">Toggleable via the navbar brand.</span>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <!-- <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
        </button> -->
        <a href="../home_page.php"><img src="../../img/logo_blanco.png" alt="Logo Formació Professional" style="width: 100px;"></a>
        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../../img/usuario.png" alt="mdo" class="rounded-circle" width="32" height="32">
        </a>
        <ul id="user_dropdown_menu" class="dropdown-menu text-small" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 34px);" data-popper-placement="bottom-end">
            <li><a class="dropdown-item" href="#">Perfil</a></li>
            <li><a class="dropdown-item" href="#">Cursos</a></li>
            <?php
              session_start();
              if(isset($_SESSION["usuari"]) && $_SESSION["usuari"] == 1){
                  echo "<li><a class='dropdown-item' href='../alta.php'>Donar d'alta</a></li>";
              }
            ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="../login.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <!-- BODY -->

    <div class="row g-5 content">
        <div class="col-md-8">
          <h2 class="pb-4 mb-4 fst-italic border-bottom">
            Curs d'Àngles
          </h2>
    
          <article class="blog-post">
            <h3>Descripció</h3>
            <p>This is some additional paragraph placeholder content. It has been written to fill the available space and show how a longer snippet of text affects the surrounding content. We'll repeat it often to keep the demonstration flowing, so be on the lookout for this exact same string of text.</p>
          </article> 
    
          <article class="blog-post">
            <h3>Continguts</h3>
            <p>And don't forget about tables in these posts:</p>
            <table class="table">
              <thead>
                <tr>
                  <th>Contingut</th>
                  <th>Descripció del contingut</th>
                  <th>Professor</th>
                  <th>Hores</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Irregular verbs</td>
                  <td>Els verbs irregulars en anglès representen un dels reptes més importants per a aprendre anglès ja que es tracta d'un dels elements gramaticals indispensables per a parlar o escriure.</td>
                  <td>Laura</td>
                  <td>5</td>
                </tr>
                <tr>
                  <td>Irregular verbs</td>
                  <td>Els verbs irregulars en anglès representen un dels reptes més importants per a aprendre anglès ja que es tracta d'un dels elements gramaticals indispensables per a parlar o escriure.</td>
                  <td>Gerard</td>
                  <td>4</td>
                </tr>
                <tr>
                  <td>Irregular verbs</td>
                  <td>Els verbs irregulars en anglès representen un dels reptes més importants per a aprendre anglès ja que es tracta d'un dels elements gramaticals indispensables per a parlar o escriure.</td>
                  <td>Laura</td>
                  <td>15</td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td>Irregular verbs</td>
                  <td>Els verbs irregulars en anglès representen un dels reptes més importants per a aprendre anglès ja que es tracta d'un dels elements gramaticals indispensables per a parlar o escriure.</td>
                  <td>Carlos</td>
                  <td>12</td>
                </tr>
              </tfoot>
            </table>
    
            <p>This is some additional paragraph placeholder content. It's a slightly shorter version of the other highly repetitive body text used throughout.</p>
          </article>   
        </div>

        <div class="col-md-4">
            <div class="position-sticky" style="top: 2rem;">

      
              <div class="p-4">
                <img src="../../img/curso-ingles.jpg" alt="Curs àngles" style="width: 25rem;">
              </div>
      
              <div class="p-4 mb-3 bg-light rounded">
                <h4 class="fst-italic">Reserva</h4>
                <p class="mb-0">Reserva una plaça amb el teu compte per a que el professor rebri la teva infomació per contactar amb tú i començar el curs.</p>
                <button id="reserva">Reserva</button>
              </div>

            </div>
          </div>
    </body>
</html>