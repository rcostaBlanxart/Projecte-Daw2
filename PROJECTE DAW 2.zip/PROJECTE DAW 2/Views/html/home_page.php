<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Pàgina Principal</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="scroll.js"></script>
    <style>
      ::selection {   
        background: orange;
      }
    </style>
  </head>
  <body>
    <!-- NAVBAR & DROPDOWN-->
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <h5 class="text-white h4">Collapsed content</h5>
        <span class="text-white">Toggleable via the navbar brand.</span>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <!-- <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
        </button> -->
        <a href="home_page.php"><img src="../img/logo_blanco.png" alt="Logo Formació Professional" style="width: 100px;"></a>

        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../img/usuario.png" alt="mdo" class="rounded-circle" width="32" height="32">
        </a>
        <ul id="user_dropdown_menu" class="dropdown-menu text-small" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 34px);" data-popper-placement="bottom-end">
            <li><a class="dropdown-item" href="perfil.php">Perfil</a></li>
            <li><a class="dropdown-item" href="#">Cursos</a></li>
            <?php
              session_start();
              if(isset($_SESSION["usuari"]) && $_SESSION["usuari"] == 1){
                  echo "<li><a class='dropdown-item' href='alta.php'>Donar d'alta</a></li>";
              }
            ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="login.php">Sign out</a></li>
        </ul>
      </div>
    </nav>
    <!-- HEADER -->
    <div class="p-4 p-md-5 mb-4 text-bg-dark" style="background-image: url('../img/cursos-online-2.jpeg'); background-size: cover; background-position: center;">
      <div class="col-md-6 px-0">
        <h1 class="display-4 fst-italic" style="font-weight: bold; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;">Formació Professional</h1>
        <p class="lead my-3" style="font-size: 1.5rem; font-weight: bold; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;">Multiple lines of text that form the lede, informing new readers quickly and efficiently about what’s most interesting in this post’s contents.</p>
        <p class="lead mb-0"><a href="#" class="text-white fw-bold"><a href="#" class="btn btn-primary my-2" onclick="scrollToCursos()">Ver cursos</a></a></p>
      </div>
    </div>

    <!-- SECTION CURSOS -->
    <section id="cursos" class="py-5 text-center container">
      <div class="row py-lg-5">
        <div class="col-lg-6 col-md-8 mx-auto">
          <h1 class="fw-light">Oferta de cursos</h1>
          <p class="lead text-muted">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
          <p>
            <a href="#" class="btn btn-warning my-2">Home Page</a>
            <a href="#" class="btn btn-secondary my-2">Mis cursos</a>
          </p>
        </div>
      </div>
    </section>
    <!-- CARDS  -->
    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="../img/curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs d'Àngles</p>
              <p class="card-text">L'àngles s'ensenya malament</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.location.href='Cursos/curs_angles.php'">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs RRHH</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs comptabilitat</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs RRSS</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs FOL presencial</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs de Software DELSOL</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">6.75€/h</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="curso_img1.webp" class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" preserveAspectRatio="xMidYMid slice" focusable="false"></img>
            <div class="card-body">
              <p class="card-text">Curs FOL presencial/telemàtic</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">3.75€/h</small>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <!-- FOOTER -->
    <div class="container">
      <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-4 mb-0 text-muted">© 2023 Formació Professional</p>
    
        <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
        </a>
    
        <ul class="nav col-md-4 justify-content-end">
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Pàgina Principal</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Cursos</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Atenció al client</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Sobre nosaltres</a></li>
        </ul>
      </footer>
    </div>

  </body>
</html>