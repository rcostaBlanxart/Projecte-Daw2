<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Reserves realitzades</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
      ::selection {   
        background: orange;
      }
      .curs {
          border: 2px outset;
          padding: 2%;
      }
      .div_curs {
        color: black;
        text-decoration: none;

        padding: 1%;
      }
      .curs:hover{
        border-color: orange;
      }
      .curs:hover .titol_curs{
        color: orange;
      }
  </style>
  </head>
  <body>
    <!-- NAVBAR & DROPDOWN-->
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <h5 class="text-white h4">Collapsed content</h5>
        <span class="text-white">Toggleable via the navbar brand.</span>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <!-- <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
        </button> -->
        <a href="home_page.php"><img src="../img/logo_blanco.png" alt="Logo Formació Professional" style="width: 100px;"></a>
        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../Views/img/hombre(1).png" alt="mdo" class="rounded-circle" width="32" height="32">
        </a>
        <ul id="user_dropdown_menu" class="dropdown-menu text-small" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 34px);" data-popper-placement="bottom-end">
            <li><a class="dropdown-item" href="#">Perfil</a></li>
            <li><a class="dropdown-item" href="#">Cursos</a></li>
            <?php
              session_start();
              if(isset($_SESSION["usuari"]) && $_SESSION["usuari"] == 1){
                  echo "<li><a class='dropdown-item' href='alta.php'>Donar d'alta</a></li>";
              }
            ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="login.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <!-- HEADER -->
    <section class="py-5 text-center container">
        <div class="row py-lg-5">
          <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light">Reserves realitzades</h1>
            <p class="lead text-muted">A continuació es mostra un llistat de totes les reserves que s'han realitzar amb tota la informació sobre aquesta.</p>
          </div>
        </div>
    </section>
        
    <!-- SECTION CURSOS -->
    <section class="py-5 text-center container">
        <div class="curs col-sm-6 mx-auto">
            <!-- <input type="color" name="" id=""> -->
            <h2 class="titol_curs">Reserva 1</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi error ex doloremque quibusdam eligendi iure, eveniet ullam? Veritatis, ut nulla?</p>
        </div>
    </section>
</body>
</html>