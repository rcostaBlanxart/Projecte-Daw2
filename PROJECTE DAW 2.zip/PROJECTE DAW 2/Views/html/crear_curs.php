<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Crear curs</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
      ::selection {   
        background: orange;
      }
      .crear_curs{
          margin: 2rem;
      }
    </style>
  </head>
  <body>
    <!-- NAVBAR & DROPDOWN-->
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <h5 class="text-white h4">Collapsed content</h5>
        <span class="text-white">Toggleable via the navbar brand.</span>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <div class="container-fluid">
        <!-- <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
        </button> -->
        <a href="home_page.php"><img src="../img/logo_blanco.png" alt="Logo Formació Professional" style="width: 100px;"></a>
        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../Views/img/hombre(1).png" alt="mdo" class="rounded-circle" width="32" height="32">
        </a>
        <ul id="user_dropdown_menu" class="dropdown-menu text-small" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 34px);" data-popper-placement="bottom-end">
            <li><a class="dropdown-item" href="#">Perfil</a></li>
            <li><a class="dropdown-item" href="#">Cursos</a></li>
            <?php
              session_start();
              if(isset($_SESSION["usuari"]) && $_SESSION["usuari"] == 1){
                  echo "<li><a class='dropdown-item' href='alta.php'>Donar d'alta</a></li>";
              }
            ?>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="login.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <!-- HEADER -->
    <section class="py-5 text-center container">
        <div class="row py-lg-5">
          <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light">Crear cursos</h1>
            <p class="lead text-muted">Aquesta pàgina proporciona la funcionalitat de crear nous cursos.</p>
          </div>
        </div>
    </section>
        
    <!-- SECTION FORM -->
    <section class="py-5 text-center container">
        <div class="input-group mb-3">
            <div class="input-group-prepend">
            </div>
            <input type="text" class="form-control" placeholder="Nom del curs" aria-label="Nom del curs" aria-describedby="basic-addon1">
        </div>
     
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Data inici" aria-label="Data inici" aria-describedby="basic-addon2">
          <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2">Ejemplo: 2008-10-29</span>
          </div>
      </div>

      <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Data fi" aria-label="Data fi" aria-describedby="basic-addon2">
        <div class="input-group-append">
        <span class="input-group-text" id="basic-addon2">Ejemplo: 2008-10-29</span>
        </div>
      </div>

      <div class="input-group mb-3">
          <div class="input-group-prepend">
          </div>
          <label for="horarios" class="m-2">Horari</label> 
          <select name="horarios" class="rounded">
            <option value=""></option>
            <option value="">Lunes de 09:00:00 a 18:00:00</option>
          </select>
      </div>

      <div class="input-group mb-3">
        <div class="input-group-prepend">
        </div>
        <label for="horarios" class="m-2">Professor</label> 
        <select name="horarios" class="rounded">
          <option value=""></option>
          <option value="">Juan Garcia</option>
        </select>
      </div>

      <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Preu" aria-label="Preu" aria-describedby="basic-addon2">
        <div class="input-group-append">
        <span class="input-group-text" id="basic-addon2">€ / h</span>
        </div>
      </div>

      <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Plaçes disponibles" aria-label="Plaçes disponibles" aria-describedby="basic-addon2">
        <div class="input-group-append">
        </div>
      </div>

      <div class="input-group">
          <div class="input-group-prepend">
          <span class="input-group-text">Descripció del curs</span>
          </div>
          <textarea class="form-control" aria-label="With textarea"></textarea>
      </div>
      <div class="crear_curs">
          <p><a class="btn btn-warning" href="#">Crear curs</a></p>
      </div>
    </section>
</body>
</html>