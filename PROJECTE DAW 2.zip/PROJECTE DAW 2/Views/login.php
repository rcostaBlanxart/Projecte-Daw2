<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="cabecera1">

        <div class="content">
            
            <img src="img/logo1.png" alt="logo1" width="200px" hegiht="250px">
            <h1>APLICATION<br>LOGIN PAGE</h1>
        
        </div>
        
    </div>
</body>
</html>