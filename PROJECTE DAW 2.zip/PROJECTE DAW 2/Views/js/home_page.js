function scrollToCursos() {
    var cursos = document.getElementById("cursos");
    cursos.scrollIntoView({behavior: "smooth"});
}