function mostrar_confirmacion(id) {
    document.getElementById(id).style.display = "block";
 }
 
 function ocultar_confirmacion(id) {
     document.getElementById(id).style.display = "none";
 }