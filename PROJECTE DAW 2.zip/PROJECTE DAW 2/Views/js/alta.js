function validateForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confPassword = document.getElementById("confPassword").value;
    var dni = document.getElementById("dni").value;
    var username = document.getElementById("username").value;
    var nom = document.getElementById("nom").value;
    var cognom = document.getElementById("cognom").value;
    var tipoUsuario = document.getElementById("tipoUsuario").value;
  
    let emailValid =/^(([^<>()\[\]\.,;:\s@\”]+(\.[^<>()\[\]\.,;:\s@\”]+)*)|(\”.+\”))@(([^<>()[\]\.,;:\s@\”]+\.)+[^<>()[\]\.,;:\s@\”]{2,})$/
    let passwordValida = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])([A-Za-z\d$@$!%*?&]|[^ ]){8,15}$/;
    let dniValid = /^[XYZ]?\d{5,8}[A-Z]$/i;;
    
  
    var formValido = true;
  
    if (username=="") {
      document.getElementById("er-username").innerHTML="Aquest camp no pot estar buit";
      formValido = false;
    }else{
      document.getElementById("er-username").innerHTML="";
    }
  
    if (nom=="") {
      document.getElementById("er-nom").innerHTML="Aquest camp no pot estar buit";
      formValido = false;
    }else{
      document.getElementById("er-nom").innerHTML="";
    }
  
    if (cognom=="") {
      document.getElementById("er-cognom").innerHTML="Aquest camp no pot estar buit";
      formValido = false;
    }else{
      document.getElementById("er-cognom").innerHTML="";
    }
  
    if (!emailValid.test(email)) {
        document.getElementById("er-mail").innerHTML="El correu electrònic no és vàlid";
        formValido = false;
    }else{
      document.getElementById("er-mail").innerHTML="";
    }
    
    if (!dniValid.test(dni)) {
        document.getElementById("er-dni").innerHTML="El dni no és vàlid";
        formValido = false;
    }else{
      document.getElementById("er-dni").innerHTML="";
    }
    
    if (!passwordValida.test(password)) {
        document.getElementById("er-pas").innerHTML="La contrasenya ha de contenir entre 8 i 15 caràcters, una minúscula, una majúscula i número i un caràcter especial.";
        formValido = false;
    }else{
      document.getElementById("er-pas").innerHTML="";
    }
    
    if (password !== confPassword) {
        document.getElementById("er-cpas").innerHTML="La contrasenya no coincideix";
        formValido = false;
    }else{
      document.getElementById("er-cpas").innerHTML="";
    }
  
    if (tipoUsuario=="") {
      document.getElementById("er-tip").innerHTML="Has de seleccionar un tipus d'usuari";
      formValido = false;
    }else{
    document.getElementById("er-tip").innerHTML="";
    }
  
    
    if (!formValido) {
        return false;
    }
  
    return true;
  
  }
  
  
  var form = document.getElementById("myForm");
  
  form.addEventListener("submit", function(event){
    event.preventDefault();
    if(validateForm()){
        form.submit();
    }
  });
  
  // let dniValid = /^[XYZ]?\d{5,8}[A-Z]$/i;
  // let dni = "20572037d";
  // let dni2 = "20572037D";
  // let dni3 = "20572037";
  
  // console.log(dniValid.test(dni))
  // console.log(dniValid.test(dni2))
  // console.log(dniValid.test(dni3))
  
  
  
  
  
  
  
  
  
  
  
  
  
  // function comprovacio(tipo){
  //   let nom = document.getElementById('nom');
  //   let email = document.getElementById('email');
  //   let password = document.getElementById('password');
  //   let confPassword = document.getElementById('confPassword');
  
  //   let emailValid =/^(([^<>()\[\]\.,;:\s@\”]+(\.[^<>()\[\]\.,;:\s@\”]+)*)|(\”.+\”))@(([^<>()[\]\.,;:\s@\”]+\.)+[^<>()[\]\.,;:\s@\”]{2,})$/
  //   let passwordValida = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.-])[A-Za-z\d@$!%*?&.-]{8,16}$/
  
  //   switch(tipo){
  //     case "email":
  //       if(emailValid.test(email.value)){
  //         document.getElementById("email").style="background-color:lightgreen;";
  //       }else{
  //         document.getElementById("email").style="background-color:#FF8080;";
  //       }
  //       break;
  //     case "password":
  //       if(passwordValida.test(password.value)){
  //         document.getElementById("password").style="background-color:lightgreen;";
  //       }else{
  //         document.getElementById("password").style="background-color:#FF8080;";
  //       }
  //       break;
  //     case "confPassword":
  //       if(password.value==confPassword.value){
  //         document.getElementById("confPassword").style="background-color:lightgreen;";
  //       }else{
  //         document.getElementById("confPassword").style="background-color:#FF8080;";
  //       }
  //   }
  
  
  
  // }
  // let p = "12345678"
  // let p1 = "12345678aA!"
  // let p2 = "12345678aA*11111"
  // let p3 = "12345678aA."
  // let passwordValida = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.-])[A-Za-z\d@$!%*?&.-]{8,16}$/
  // console.log(passwordValida.test(p))
  // console.log(passwordValida.test(p1))
  // console.log(passwordValida.test(p2))
  // console.log(passwordValida.test(p3))
  
  
  
  
  
  
  
  
  
  
  